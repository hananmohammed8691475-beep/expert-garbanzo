package xyz.stark.starksayall;

import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import com.google.inject.Inject;
import com.velocitypowered.api.command.CommandMeta;
import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.proxy.ProxyInitializeEvent;
import com.velocitypowered.api.plugin.Plugin;
import com.velocitypowered.api.plugin.annotation.DataDirectory;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.messages.MinecraftChannelIdentifier;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.slf4j.Logger;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.HashSet;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;

@Plugin(id = "starksayall", name = "StarkSayAll", version = "1.0.0", authors = {"Ahmed"})
public final class StarkSayAll {

    public static final MinecraftChannelIdentifier CHANNEL = MinecraftChannelIdentifier.create("starksayall", "main");
    private static final LegacyComponentSerializer SER =
            LegacyComponentSerializer.builder().character('&').hexColors().build();

    private final ProxyServer server;
    private final Logger logger;
    private final Path dir;

    private Map<String, Object> config = new HashMap<>();

    @Inject
    public StarkSayAll(ProxyServer server, Logger logger, @DataDirectory Path dir) {
        this.server = server;
        this.logger = logger;
        this.dir = dir;
    }

    @Subscribe
    public void onInit(ProxyInitializeEvent e) {
        loadConfig();
        server.getChannelRegistrar().register(CHANNEL);
        CommandMeta meta = server.getCommandManager().metaBuilder("taaall").plugin(this).build();
        server.getCommandManager().register(meta, new SayCommand());
        logger.info("StarkSayAll enabled.");
    }

    private final class SayCommand implements SimpleCommand {
        @Override
        public void execute(Invocation inv) {
            CommandSource src = inv.source();
            if (src instanceof Player && !src.hasPermission(cfg("permission", "starksayall.use"))) {
                src.sendMessage(SER.deserialize(cfg("messages.no-permission", "&cNo permission.")));
                return;
            }
            String text = String.join(" ", inv.arguments()).trim();
            if (text.isEmpty()) {
                src.sendMessage(SER.deserialize(cfg("messages.empty-message", "&cEmpty message.")));
                return;
            }
            Set<String> targets = new HashSet<>();
            for (RegisteredServer rs : server.getAllServers()) targets.add(rs.getServerInfo().getName());
            broadcast(text, targets);
        }
    }

    private void broadcast(String text, Set<String> targets) {
        Component title = SER.deserialize(cfg("announcement.title", "&b&lSTARK MC").replace("{message}", text));
        Component sub = SER.deserialize(cfg("announcement.subtitle", "&f{message}").replace("{message}", text));
        int seconds = (int) num("announcement.duration", 5);
        Title t = Title.title(title, sub, Title.Times.times(
                Duration.ofMillis(500), Duration.ofSeconds(seconds), Duration.ofSeconds(1)));

        for (Player pl : server.getAllPlayers()) {
            pl.getCurrentServer().ifPresent(c -> {
                if (targets.contains(c.getServerInfo().getName())) pl.showTitle(t);
            });
        }

        String sound = cfg("announcement.sound", "").trim();
        if (!sound.isEmpty()) {
            ByteArrayDataOutput out = ByteStreams.newDataOutput();
            out.writeUTF("SOUND");
            out.writeUTF(sound);
            out.writeFloat((float) num("announcement.sound-volume", 1.0));
            out.writeFloat((float) num("announcement.sound-pitch", 1.0));
            byte[] data = out.toByteArray();
            for (String name : targets) {
                server.getServer(name).ifPresent(rs -> rs.sendPluginMessage(CHANNEL, data));
            }
        }
    }

    @SuppressWarnings("unchecked")
    private void loadConfig() {
        try {
            Files.createDirectories(dir);
            Path f = dir.resolve("config.yml");
            if (!Files.exists(f)) {
                try (InputStream in = getClass().getResourceAsStream("/config.yml")) {
                    Files.copy(in, f);
                }
            }
            try (Reader r = Files.newBufferedReader(f, StandardCharsets.UTF_8)) {
                Object o = new Yaml().load(r);
                if (o instanceof Map<?, ?> m) config = (Map<String, Object>) m;
            }
        } catch (Exception ex) {
            logger.error("Failed to load config.yml", ex);
        }
    }

    private String cfg(String path, String def) {
        Object cur = config;
        for (String k : path.split("\\.")) {
            if (cur instanceof Map<?, ?> m) cur = m.get(k); else return def;
        }
        return cur == null ? def : String.valueOf(cur);
    }

    private double num(String path, double def) {
        try { return Double.parseDouble(cfg(path, String.valueOf(def))); } catch (NumberFormatException e) { return def; }
    }
}
