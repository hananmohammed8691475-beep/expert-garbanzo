package xyz.stark.starksayall;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteStreams;
import org.bukkit.Bukkit;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.PluginMessageListener;

public final class StarkSayAllBridge extends JavaPlugin implements PluginMessageListener {

    private static final String CHANNEL = "starksayall:main";

    @Override
    public void onEnable() {
        getServer().getMessenger().registerIncomingPluginChannel(this, CHANNEL, this);
    }

    @Override
    public void onPluginMessageReceived(String channel, Player carrier, byte[] message) {
        if (!channel.equals(CHANNEL)) return;
        ByteArrayDataInput in = ByteStreams.newDataInput(message);
        if (!in.readUTF().equals("SOUND")) return;
        String key = in.readUTF();
        float volume = in.readFloat();
        float pitch = in.readFloat();
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.playSound(p.getLocation(), key, SoundCategory.MASTER, volume, pitch);
        }
    }
}
